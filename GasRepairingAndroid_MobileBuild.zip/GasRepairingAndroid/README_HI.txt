Gas Repairing Services — मोबाइल से APK बनाने वाला Android प्रोजेक्ट

यह ZIP तैयार APK नहीं है। इसमें GitHub Actions workflow भी है, जिससे GitHub पर प्रोजेक्ट अपलोड करने के बाद APK ऑनलाइन बन सकती है।

मोबाइल से APK बनाने के चरण:
1. ZIP को मोबाइल में डाउनलोड करके Extract करें।
2. Chrome में https://github.com खोलें और अकाउंट में Sign in/Sign up करें।
3. नया repository बनाएं: नाम GasRepairingServices रखें और Public चुनें (workflow आसान रखने के लिए)। README, .gitignore या License को GitHub पर अलग से बनाना जरूरी नहीं।
4. Repository में Add file > Upload files चुनें। Extract किए गए प्रोजेक्ट के अंदर की सभी फाइलें/फ़ोल्डर अपलोड करें। ध्यान रखें कि .github फ़ोल्डर भी अपलोड हो, उसमें workflows/build-apk.yml मौजूद है। फिर Commit changes दबाएं।
5. Repository के Actions टैब में जाएं। “Build Gas Repairing Services APK” workflow खोलें। अगर build अपने-आप शुरू न हो तो Run workflow दबाएं।
6. Build सफल होने पर उसी workflow run के नीचे Artifacts में GasRepairingServices-debug-apk डाउनलोड करें। ZIP खोलकर app-debug.apk निकालें।
7. APK पर टैप करके इंस्टॉल करें। Android पूछे तो केवल इसी अपनी बनाई APK के लिए ब्राउज़र/फ़ाइल मैनेजर से “Install unknown apps” की अनुमति दें। इंस्टॉल के बाद चाहें तो अनुमति बंद कर दें।

ध्यान दें:
- GitHub account चाहिए; upload और build ऑनलाइन होंगे, इसलिए इंटरनेट जरूरी है।
- GitHub मोबाइल वेबसाइट पर .github जैसे hidden-folder upload मुश्किल हो सकता है। अगर folder upload नहीं हो रहा, GitHub की desktop site को Chrome menu (⋮) से चालू करें या Android पर ZIP को GitHub-compatible file uploader से अपलोड करें।
- यह ऐप अभी starter demo है: बुकिंग लोकल डिवाइस में सेव होती है; अलग-अलग ग्राहकों के फोन और मालिक के फोन में ऑनलाइन sync नहीं है। स्वतः WhatsApp/background notifications नहीं हैं।
- डेमो admin login admin/1234 को वास्तविक उपयोग के लिए सुरक्षित न मानें।
